/*
Xan Varcoe's build of Naughts and Crosses
*/

public class Oxo {
   public static void main(String[] args) {
      Game game = new Game();
   }
}
