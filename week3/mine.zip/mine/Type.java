enum Type {
    Naught, Cross, Empty, Full;
}
