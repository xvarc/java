/* this interfaces all the other areas
 - it checks to see if there are wins or losses.
 - it does all of the calculations basically.
 - examples of functions that go inside :
   - start the players (making instances of player)
   - it prints the board
   - checks for wins or losses
   - checks if the board is full


*/

public class Play {

   Play() {
      Board board = new Board();
   }
}
