/* Define constants for different types of triangle. */

enum Type {
    Equilateral, Isosceles, Scalene, Right, Flat, Impossible, Illegal;
}
